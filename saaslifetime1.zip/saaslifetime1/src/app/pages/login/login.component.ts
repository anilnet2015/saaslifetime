import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Alert } from '../../classes/alert';
import { AlertType } from '../../enums/alert-type.enum';
import { AlertService } from '../../services/alert.service';
import { Subscription } from 'rxjs/Subscription';
import { AuthService } from '../../services/auth.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, OnDestroy {
  public loginForm: FormGroup;
  public subscriptions: Subscription[] = [];
  private returnUrl: string;
  constructor(private fb: FormBuilder, private alertService: AlertService,
  private auth: AuthService,
    private router: Router,
  private route: ActivatedRoute) {
    this.createForm();
  }

  ngOnInit() {
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/alldeals';
  }
  ngOnDestroy() {
    this.subscriptions.forEach(sub => sub.unsubscribe());
  }
  private createForm(): void {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]],
    });
  }
  private displayFailedLogin(): void {
    const failedLoginAlert = new Alert('Email or Password were invalid, try again.', AlertType.Danger);
    this.alertService.alerts.next(failedLoginAlert);
  }
  public submit(): void {
    if (this.loginForm.valid) {
    const {email, password} = this.loginForm.value;
    this.subscriptions.push(this.auth.login(email, password).subscribe(success => {
      if (success) {
        this.router.navigateByUrl(this.returnUrl);
      }
    }));
    // console.log(`Email: ${email}, Password: ${password}`);
  } else {
    this.displayFailedLogin();
  }
}

}
