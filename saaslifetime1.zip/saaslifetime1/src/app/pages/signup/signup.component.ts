import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Alert } from '../../classes/alert';
import { AlertType } from '../../enums/alert-type.enum';
import { AlertService } from '../../services/alert.service';
import { AuthService } from '../../services/auth.service';
import { Subscription } from 'rxjs/Subscription';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit, OnDestroy {

  public signupForm: FormGroup;
  public subscriptions: Array<Subscription> = [];
  constructor(private fb: FormBuilder,
  private alertService: AlertService,
  private auth: AuthService,
  private router: Router,
  ) {
    this.createForm();
  }

  ngOnInit() {
  }
  private createForm(): void {
    this.signupForm = this.fb.group({
      firstName: ['', [Validators.required]],
      lastName: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]],
    });
  }
  public submit(): void {
    if (this.signupForm.valid) {
    const {firstName, lastName, email, password} = this.signupForm.value;
    this.subscriptions.push(this.auth.signup(firstName, lastName, email, password).subscribe(success => {
      if (success) {
        this.router.navigate(['/alldeals']);
      } else {
         const failedSignupAlert = new Alert('There was a problem signing up, try again.', AlertType.Danger);
         this.alertService.alerts.next(failedSignupAlert);
      }
    }));
    console.log(`First Name: ${firstName}, Last Name: ${lastName}, Email: ${email}, Password: ${password}`);
  } else {
     const failedSignupAlert = new Alert('Enter a valid name, Email or Password were invalid, try again.', AlertType.Danger);
    this.alertService.alerts.next(failedSignupAlert);
  }
}

ngOnDestroy() {
  this.subscriptions.forEach(sub => sub.unsubscribe());
}
}
