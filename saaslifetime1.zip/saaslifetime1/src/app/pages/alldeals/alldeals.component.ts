import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alldeals',
  templateUrl: './alldeals.component.html',
  styleUrls: ['./alldeals.component.scss']
})
export class AlldealsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
