export const environment = {
  production: true,
  firebase: {
  apiKey: 'AIzaSyDSbKXJL1lWeKQC7OJMN3N_5kSrfuWEIL8',
  authDomain: 'saaslifetime.firebaseapp.com',
  databaseURL: 'https://saaslifetime.firebaseio.com',
  projectId: 'saaslifetime',
  storageBucket: 'saaslifetime.appspot.com',
  messagingSenderId: '312793937949'
  }
};
